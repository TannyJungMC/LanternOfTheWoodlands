package tannyjung.tanshugetrees.procedures;

public class ConfigApplyProcedure {
	public static void execute() {
		tannyjung.tanshugetrees_handcode.config.ConfigMain.apply();
	}
}
