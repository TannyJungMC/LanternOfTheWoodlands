
package net.mcreator.skywiza.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class QuestPaper21Item extends Item {
	public QuestPaper21Item() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}
}
