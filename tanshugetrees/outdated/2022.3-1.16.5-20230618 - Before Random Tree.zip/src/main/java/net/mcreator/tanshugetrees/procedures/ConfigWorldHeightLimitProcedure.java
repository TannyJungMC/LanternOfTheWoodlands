package net.mcreator.tanshugetrees.procedures;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.command.arguments.MessageArgument;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.CommandSource;

import net.mcreator.tanshugetrees.ThtModVariables;
import net.mcreator.tanshugetrees.ThtMod;

import java.util.Map;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContext;

public class ConfigWorldHeightLimitProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				ThtMod.LOGGER.warn("Failed to load dependency world for procedure ConfigWorldHeightLimit!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				ThtMod.LOGGER.warn("Failed to load dependency x for procedure ConfigWorldHeightLimit!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				ThtMod.LOGGER.warn("Failed to load dependency y for procedure ConfigWorldHeightLimit!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				ThtMod.LOGGER.warn("Failed to load dependency z for procedure ConfigWorldHeightLimit!");
			return;
		}
		if (dependencies.get("arguments") == null) {
			if (!dependencies.containsKey("arguments"))
				ThtMod.LOGGER.warn("Failed to load dependency arguments for procedure ConfigWorldHeightLimit!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		CommandContext<CommandSource> arguments = (CommandContext<CommandSource>) dependencies.get("arguments");
		String set = "";
		set = (new Object() {
			public String getMessage() {
				try {
					return MessageArgument.getMessage(arguments, "world_height_limit").getString();
				} catch (CommandSyntaxException ignored) {
					return "";
				}
			}
		}).getMessage();
		if (!(set).equals("?")) {
			if (world instanceof ServerWorld) {
				((World) world).getServer().getCommandManager().handleCommand(
						new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
								new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
						("execute if entity @p[distance=..0.01] run tellraw @a [\"\",{\"text\":\"Tan's Huge Trees : \",\"color\":\"gray\"},{\"text\":\"Set "
								+ "world height limit" + " to " + set + "\",\"color\":\"yellow\"}]"));
			}
		}
		if ((set).equals("?")) {
			set = ("" + ThtModVariables.MapVariables.get(world).world_height_limit);
		} else {
			ThtModVariables.MapVariables.get(world).world_height_limit = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(set);
			ThtModVariables.MapVariables.get(world).syncData(world);
		}
		if (((new Object() {
			public String getMessage() {
				try {
					return MessageArgument.getMessage(arguments, "world_height_limit").getString();
				} catch (CommandSyntaxException ignored) {
					return "";
				}
			}
		}).getMessage()).equals("?")) {
			if (world instanceof ServerWorld) {
				((World) world).getServer().getCommandManager().handleCommand(
						new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
								new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
						("execute if entity @p[distance=..0.01] run tellraw @a [\"\",{\"text\":\"Tan's Huge Trees : \",\"color\":\"gray\"},{\"text\":\"Current value of "
								+ "world height limit" + " is " + set + "\",\"color\":\"yellow\"}]"));
			}
		}
	}
}
