
package tannyjung.lanternofthewoodlands.client.screens;

import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnTypeUnselectedProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnTypeSwordProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnTypeShieldProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnTypeLanternProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnTypeKnightSwordProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnTypeBowProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnTypeAnchorProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnTypeAllProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnReverseTrueProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnLockTargetTrueProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnHomingTrueProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnDistanceProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnConstantTrueProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnAbilityDurationTrueProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnAbilityDurationProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnAbilityCooldownTrueProcedure;
import tannyjung.lanternofthewoodlands.procedures.Spell4GUIreturnAbilityCooldownProcedure;
import tannyjung.lanternofthewoodlands.procedures.OVERLAYSpell4ModeProcedure;

import org.checkerframework.checker.units.qual.h;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.Minecraft;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;

@Mod.EventBusSubscriber({Dist.CLIENT})
public class OVERLAYSpell4Overlay {
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		RenderSystem.disableDepthTest();
		RenderSystem.depthMask(false);
		RenderSystem.enableBlend();
		RenderSystem.setShader(GameRenderer::getPositionTexShader);
		RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
		RenderSystem.setShaderColor(1, 1, 1, 1);
		if (true) {
			event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/symbol_homing.png"), 14, 76, 0, 0, 8, 8, 8, 8);

			if (Spell4GUIreturnHomingTrueProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/symbol_homing_2s.png"), 14, 76, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/symbol_constant.png"), 6, 76, 0, 0, 8, 8, 8, 8);

			if (Spell4GUIreturnConstantTrueProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/symbol_constant_2s.png"), 6, 76, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/symbol_lock_target.png"), 6, 68, 0, 0, 8, 8, 8, 8);

			if (Spell4GUIreturnLockTargetTrueProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/symbol_lock_target_2s.png"), 6, 68, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/symbol_reverse.png"), 14, 68, 0, 0, 8, 8, 8, 8);

			if (Spell4GUIreturnReverseTrueProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/symbol_reverse_2s.png"), 14, 68, 0, 0, 8, 8, 8, 8);
			}
			if (Spell4GUIreturnTypeAllProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_all.png"), 6, 8, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeUnselectedProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_nothing.png"), 6, 8, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeSwordProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_sword_manipulation.png"), 6, 8, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeShieldProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_shield_manipulation.png"), 6, 8, 0, 0, 16, 16, 16, 16);
			}
			event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_nothing.png"), 6, 48, 0, 0, 16, 16, 16, 16);

			if (Spell4GUIreturnTypeSwordProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_hidden_objects.png"), 6, 48, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeLanternProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_lantern_manipulation.png"), 6, 8, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeBowProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_bow_manipulation.png"), 6, 8, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeBowProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_rain_of_arrows.png"), 6, 48, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeLanternProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_lantern_light.png"), 6, 48, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeShieldProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_the_flying_horses.png"), 6, 48, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeAnchorProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_anchor_retrieval.png"), 6, 48, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeAnchorProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_lost_anchor.png"), 6, 8, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnAbilityDurationTrueProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/cooldown.png"), 6, 48, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnAbilityCooldownTrueProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/cooldown.png"), 6, 48, 0, 0, 16, 16, 16, 16);
			}
			if (Spell4GUIreturnTypeKnightSwordProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/icon_spell_knight_sword.png"), 6, 8, 0, 0, 16, 16, 16, 16);
			}

			event.getGuiGraphics().blit(new ResourceLocation("lanternofthewoodlands:textures/screens/overlay_spell4_mode.png"), 6, h / 2 + -8, Mth.clamp((int) OVERLAYSpell4ModeProcedure.execute(entity) * 16, 0, 48), 0, 16, 16, 64, 16);

			if (Spell4GUIreturnAbilityCooldownTrueProcedure.execute(entity))
				event.getGuiGraphics().drawString(Minecraft.getInstance().font,

						Spell4GUIreturnAbilityCooldownProcedure.execute(entity), 9, 53, -3407668, false);
			if (Spell4GUIreturnAbilityDurationTrueProcedure.execute(entity))
				event.getGuiGraphics().drawString(Minecraft.getInstance().font,

						Spell4GUIreturnAbilityDurationProcedure.execute(entity), 9, 53, -602122, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font,

					Spell4GUIreturnDistanceProcedure.execute(entity), 26, 72, -13421773, false);
		}
		RenderSystem.depthMask(true);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableDepthTest();
		RenderSystem.disableBlend();
		RenderSystem.setShaderColor(1, 1, 1, 1);
	}
}
