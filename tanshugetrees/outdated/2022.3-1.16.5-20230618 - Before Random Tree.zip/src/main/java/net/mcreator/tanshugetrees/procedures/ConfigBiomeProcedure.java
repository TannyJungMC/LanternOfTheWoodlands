package net.mcreator.tanshugetrees.procedures;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.command.arguments.MessageArgument;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.CommandSource;

import net.mcreator.tanshugetrees.ThtModVariables;
import net.mcreator.tanshugetrees.ThtMod;

import java.util.Map;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.StringArgumentType;

public class ConfigBiomeProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				ThtMod.LOGGER.warn("Failed to load dependency world for procedure ConfigBiome!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				ThtMod.LOGGER.warn("Failed to load dependency x for procedure ConfigBiome!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				ThtMod.LOGGER.warn("Failed to load dependency y for procedure ConfigBiome!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				ThtMod.LOGGER.warn("Failed to load dependency z for procedure ConfigBiome!");
			return;
		}
		if (dependencies.get("arguments") == null) {
			if (!dependencies.containsKey("arguments"))
				ThtMod.LOGGER.warn("Failed to load dependency arguments for procedure ConfigBiome!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		CommandContext<CommandSource> arguments = (CommandContext<CommandSource>) dependencies.get("arguments");
		String set = "";
		set = (new Object() {
			public String getMessage() {
				try {
					return MessageArgument.getMessage(arguments, "biome_id").getString();
				} catch (CommandSyntaxException ignored) {
					return "";
				}
			}
		}).getMessage();
		if (!(set).equals("?")) {
			if (world instanceof ServerWorld) {
				((World) world).getServer().getCommandManager().handleCommand(
						new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
								new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
						("execute if entity @p[distance=..0.01] run tellraw @a [\"\",{\"text\":\"Tan's Huge Trees : \",\"color\":\"gray\"},{\"text\":\"Set biome for "
								+ "" + StringArgumentType.getString(arguments, "id") + " to " + set + "\",\"color\":\"yellow\"}]"));
			}
		}
		if (true) {
			if (("A1").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a1_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a1_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("A2").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a2_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a2_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("A3").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a3_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a3_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("A4").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a4_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a4_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("A5").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a5_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a5_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("A6").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a6_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a6_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("A7").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a7_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a7_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("A8").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a8_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a8_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("A9").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).a9_biome;
				} else {
					ThtModVariables.MapVariables.get(world).a9_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
		}
		if (true) {
			if (("B1").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b1_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b1_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B2").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b2_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b2_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B3").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b3_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b3_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B4").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b4_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b4_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B5").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b5_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b5_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B6").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b6_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b6_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B7").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b7_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b7_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B8").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b8_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b8_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B9").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b9_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b9_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B10").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b10_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b10_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B11").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b11_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b11_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B12").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b12_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b12_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B13").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b13_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b13_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B14").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b14_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b14_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("B15").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).b15_biome;
				} else {
					ThtModVariables.MapVariables.get(world).b15_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
		}
		if (true) {
			if (("C1").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c1_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c1_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C2").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c2_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c2_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C3").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c3_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c3_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C4").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c4_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c4_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C5").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c5_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c5_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C6").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c6_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c6_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C7").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c7_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c7_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C8").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c8_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c8_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C9").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c9_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c9_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C10").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c10_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c10_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C11").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c11_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c11_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C12").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c12_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c12_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C13").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c13_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c13_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("C14").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).c14_biome;
				} else {
					ThtModVariables.MapVariables.get(world).c14_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
		}
		if (true) {
			if (("D1").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d1_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d1_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D2").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d2_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d2_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D3").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d3_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d3_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D4").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d4_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d4_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D5").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d5_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d5_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D6").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d6_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d6_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D7").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d7_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d7_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D8").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d8_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d8_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D9").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d9_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d9_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D10").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d10_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d10_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D11").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d11_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d11_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D12").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d12_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d12_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D13").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d13_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d13_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D14").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d14_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d14_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("D15").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).d15_biome;
				} else {
					ThtModVariables.MapVariables.get(world).d15_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
		}
		if (true) {
			if (("E1").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e1_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e1_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E2").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e2_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e2_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E3").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e3_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e3_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E4").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e4_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e4_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E5").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e5_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e5_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E6").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e6_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e6_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E7").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e7_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e7_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E8").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e8_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e8_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E9").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e9_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e9_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E10").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e10_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e10_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E11").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e11_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e11_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E12").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e12_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e12_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E13").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e13_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e13_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E14").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e14_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e14_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
			if (("E15").equals(StringArgumentType.getString(arguments, "id"))) {
				if ((set).equals("?")) {
					set = ThtModVariables.MapVariables.get(world).e15_biome;
				} else {
					ThtModVariables.MapVariables.get(world).e15_biome = set;
					ThtModVariables.MapVariables.get(world).syncData(world);
				}
			}
		}
		if (((new Object() {
			public String getMessage() {
				try {
					return MessageArgument.getMessage(arguments, "biome_id").getString();
				} catch (CommandSyntaxException ignored) {
					return "";
				}
			}
		}).getMessage()).equals("?")) {
			if (world instanceof ServerWorld) {
				((World) world).getServer().getCommandManager().handleCommand(
						new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
								new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
						("execute if entity @p[distance=..0.01] run tellraw @a [\"\",{\"text\":\"Tan's Huge Trees : \",\"color\":\"gray\"},{\"text\":\"Biome of "
								+ "" + StringArgumentType.getString(arguments, "id") + " is " + set + "\",\"color\":\"yellow\"}]"));
			}
		}
	}
}
