package net.mcreator.tanshugetrees.procedures;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.gen.feature.template.Template;
import net.minecraft.world.gen.feature.template.PlacementSettings;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Mirror;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.CommandSource;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;

import net.mcreator.tanshugetrees.ThtModVariables;
import net.mcreator.tanshugetrees.ThtMod;

import java.util.stream.Stream;
import java.util.Random;
import java.util.Map;
import java.util.HashMap;
import java.util.AbstractMap;

public class D9placeProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				ThtMod.LOGGER.warn("Failed to load dependency world for procedure D9place!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				ThtMod.LOGGER.warn("Failed to load dependency x for procedure D9place!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				ThtMod.LOGGER.warn("Failed to load dependency y for procedure D9place!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				ThtMod.LOGGER.warn("Failed to load dependency z for procedure D9place!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		String ground_block = "";
		String biome = "";
		double size_z = 0;
		double place_down = 0;
		double size_y = 0;
		double size_x = 0;
		double random_rotation = 0;
		size_x = (100 / 2);
		size_y = 200;
		size_z = (500 / 2);
		place_down = 50;
		biome = ThtModVariables.MapVariables.get(world).d9_biome;
		ground_block = ThtModVariables.MapVariables.get(world).d9_ground_block;
		if (true) {
			if (!world.isRemote()) {
				BlockPos _bp = new BlockPos(x, y, z);
				TileEntity _tileEntity = world.getTileEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_tileEntity != null)
					_tileEntity.getTileData().putDouble("sizeX", size_x);
				if (world instanceof World)
					((World) world).notifyBlockUpdate(_bp, _bs, _bs, 3);
			}
			if (!world.isRemote()) {
				BlockPos _bp = new BlockPos(x, y, z);
				TileEntity _tileEntity = world.getTileEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_tileEntity != null)
					_tileEntity.getTileData().putDouble("sizeY", size_y);
				if (world instanceof World)
					((World) world).notifyBlockUpdate(_bp, _bs, _bs, 3);
			}
			if (!world.isRemote()) {
				BlockPos _bp = new BlockPos(x, y, z);
				TileEntity _tileEntity = world.getTileEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_tileEntity != null)
					_tileEntity.getTileData().putDouble("sizeZ", size_z);
				if (world instanceof World)
					((World) world).notifyBlockUpdate(_bp, _bs, _bs, 3);
			}
			if (!world.isRemote()) {
				BlockPos _bp = new BlockPos(x, y, z);
				TileEntity _tileEntity = world.getTileEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_tileEntity != null)
					_tileEntity.getTileData().putDouble("place_down", place_down);
				if (world instanceof World)
					((World) world).notifyBlockUpdate(_bp, _bs, _bs, 3);
			}
			if (!world.isRemote()) {
				BlockPos _bp = new BlockPos(x, y, z);
				TileEntity _tileEntity = world.getTileEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_tileEntity != null)
					_tileEntity.getTileData().putString("biome", biome);
				if (world instanceof World)
					((World) world).notifyBlockUpdate(_bp, _bs, _bs, 3);
			}
			if (!world.isRemote()) {
				BlockPos _bp = new BlockPos(x, y, z);
				TileEntity _tileEntity = world.getTileEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_tileEntity != null)
					_tileEntity.getTileData().putString("ground_block", ground_block);
				if (world instanceof World)
					((World) world).notifyBlockUpdate(_bp, _bs, _bs, 3);
			}
		}
		if (true) {
			if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.EMERALD_BLOCK) {
				place_down = 0;
			}
			PlaceTestProcedure.executeProcedure(Stream
					.of(new AbstractMap.SimpleEntry<>("world", world), new AbstractMap.SimpleEntry<>("x", x), new AbstractMap.SimpleEntry<>("y", y),
							new AbstractMap.SimpleEntry<>("z", z))
					.collect(HashMap::new, (_m, _e) -> _m.put(_e.getKey(), _e.getValue()), Map::putAll));
			if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.AIR)) {
				random_rotation = (MathHelper.nextInt(new Random(), 1, 8));
				if (random_rotation == 1) {
					if (world instanceof ServerWorld) {
						Template template = ((ServerWorld) world).getStructureTemplateManager()
								.getTemplateDefaulted(new ResourceLocation("tht", "d9"));
						if (template != null) {
							template.func_237144_a_((ServerWorld) world, new BlockPos(x - size_x, y - place_down, z - size_z),
									new PlacementSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setChunk(null).setIgnoreEntities(false),
									((World) world).rand);
						}
					}
				} else if (random_rotation == 2) {
					if (world instanceof ServerWorld) {
						Template template = ((ServerWorld) world).getStructureTemplateManager()
								.getTemplateDefaulted(new ResourceLocation("tht", "d9"));
						if (template != null) {
							template.func_237144_a_(
									(ServerWorld) world, new BlockPos(x + size_x, y - place_down, z - size_z), new PlacementSettings()
											.setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setChunk(null).setIgnoreEntities(false),
									((World) world).rand);
						}
					}
				} else if (random_rotation == 3) {
					if (world instanceof ServerWorld) {
						Template template = ((ServerWorld) world).getStructureTemplateManager()
								.getTemplateDefaulted(new ResourceLocation("tht", "d9"));
						if (template != null) {
							template.func_237144_a_(
									(ServerWorld) world, new BlockPos(x + size_x, y - place_down, z + size_z), new PlacementSettings()
											.setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setChunk(null).setIgnoreEntities(false),
									((World) world).rand);
						}
					}
				} else if (random_rotation == 4) {
					if (world instanceof ServerWorld) {
						Template template = ((ServerWorld) world).getStructureTemplateManager()
								.getTemplateDefaulted(new ResourceLocation("tht", "d9"));
						if (template != null) {
							template.func_237144_a_(
									(ServerWorld) world, new BlockPos(x - size_x, y - place_down, z + size_z), new PlacementSettings()
											.setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setChunk(null).setIgnoreEntities(false),
									((World) world).rand);
						}
					}
				} else if (random_rotation == 5) {
					if (world instanceof ServerWorld) {
						Template template = ((ServerWorld) world).getStructureTemplateManager()
								.getTemplateDefaulted(new ResourceLocation("tht", "d9"));
						if (template != null) {
							template.func_237144_a_(
									(ServerWorld) world, new BlockPos(x + size_x, y - place_down, z - size_z), new PlacementSettings()
											.setRotation(Rotation.NONE).setMirror(Mirror.FRONT_BACK).setChunk(null).setIgnoreEntities(false),
									((World) world).rand);
						}
					}
				} else if (random_rotation == 6) {
					if (world instanceof ServerWorld) {
						Template template = ((ServerWorld) world).getStructureTemplateManager()
								.getTemplateDefaulted(new ResourceLocation("tht", "d9"));
						if (template != null) {
							template.func_237144_a_(
									(ServerWorld) world, new BlockPos(x + size_x, y - place_down, z + size_z), new PlacementSettings()
											.setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.FRONT_BACK).setChunk(null).setIgnoreEntities(false),
									((World) world).rand);
						}
					}
				} else if (random_rotation == 7) {
					if (world instanceof ServerWorld) {
						Template template = ((ServerWorld) world).getStructureTemplateManager()
								.getTemplateDefaulted(new ResourceLocation("tht", "d9"));
						if (template != null) {
							template.func_237144_a_(
									(ServerWorld) world, new BlockPos(x - size_x, y - place_down, z + size_z), new PlacementSettings()
											.setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.FRONT_BACK).setChunk(null).setIgnoreEntities(false),
									((World) world).rand);
						}
					}
				} else if (random_rotation == 8) {
					if (world instanceof ServerWorld) {
						Template template = ((ServerWorld) world).getStructureTemplateManager()
								.getTemplateDefaulted(new ResourceLocation("tht", "d9"));
						if (template != null) {
							template.func_237144_a_((ServerWorld) world, new BlockPos(x - size_x, y - place_down, z - size_z), new PlacementSettings()
									.setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.FRONT_BACK).setChunk(null).setIgnoreEntities(false),
									((World) world).rand);
						}
					}
				}
				if (world instanceof ServerWorld) {
					((World) world).getServer().getCommandManager().handleCommand(
							new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
									new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
							("kill @e[type=item,distance=.." + size_x * 2 + "]"));
				}
			}
		}
	}
}
