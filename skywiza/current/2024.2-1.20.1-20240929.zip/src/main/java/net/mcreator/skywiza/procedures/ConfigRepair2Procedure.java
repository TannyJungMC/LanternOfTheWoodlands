package net.mcreator.skywiza.procedures;

import java.io.File;

public class ConfigRepair2Procedure {
	public static void execute() {
		File file = new File("");
	}
}
