package net.mcreator.skywiza.procedures;

import net.minecraft.world.entity.Entity;

import java.util.Calendar;

public class RealTimeCountdownProcedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		String second_set = "";
		String minute_set = "";
		String hour_set = "";
		String variable_text = "";
		double hour = 0;
		double minute = 0;
		double second = 0;
		double hour_test = 0;
		double minute_test = 0;
		double second_test = 0;
		double second_countdown = 0;
		double minute_countdown = 0;
		double hour_countdown = 0;
		if (true) {
			entity.getPersistentData().putDouble("countdown_time_minute", (entity.getPersistentData().getDouble("reset_time_minute")));
			entity.getPersistentData().putDouble("countdown_time_hour", (entity.getPersistentData().getDouble("reset_time_hour")));
			entity.getPersistentData().putDouble("countdown_time_offset", (entity.getPersistentData().getDouble("reset_time_offset")));
		}
		if (true) {
			second = Calendar.getInstance().get(Calendar.SECOND);
			minute = Calendar.getInstance().get(Calendar.MINUTE);
			hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
			minute = minute + (entity.getPersistentData().getDouble("countdown_time_offset") / 1000 - Math.floor(entity.getPersistentData().getDouble("countdown_time_offset") / 1000)) * 60;
			hour = hour + Math.floor(entity.getPersistentData().getDouble("countdown_time_offset") / 1000);
		}
		minute_countdown = entity.getPersistentData().getDouble("countdown_time_minute");
		hour_countdown = entity.getPersistentData().getDouble("countdown_time_hour");
		if (minute_countdown == 0) {
			minute_countdown = 60;
		}
		if (true) {
			if (true) {
				second_test = (60 - (second / 60 - Math.floor(second / 60)) * 60) - 1;
				if (minute / minute_countdown - Math.floor(minute / minute_countdown) == 0) {
					minute_test = 0;
				} else {
					minute_test = minute_countdown - (minute / minute_countdown - Math.floor(minute / minute_countdown)) * minute_countdown;
				}
				if (hour / hour_countdown - Math.floor(hour / hour_countdown) == 0) {
					hour_test = 0;
				} else {
					hour_test = hour_countdown - (hour / hour_countdown - Math.floor(hour / hour_countdown)) * hour_countdown;
				}
			}
			if (true) {
				if (10 > second_test) {
					second_set = "0" + (new java.text.DecimalFormat("##.#").format(second_test)).replace(".0", "");
				} else {
					second_set = (new java.text.DecimalFormat("##.#").format(second_test)).replace(".0", "");
				}
				if (10 > minute_test) {
					minute_set = "0" + (new java.text.DecimalFormat("##.#").format(minute_test)).replace(".0", "");
				} else {
					minute_set = (new java.text.DecimalFormat("##.#").format(minute_test)).replace(".0", "");
				}
				if (10 > hour_test) {
					hour_set = "0" + (new java.text.DecimalFormat("##.#").format(hour_test)).replace(".0", "");
				} else {
					hour_set = (new java.text.DecimalFormat("##.#").format(hour_test)).replace(".0", "");
				}
			}
		}
		if (hour_countdown != 0) {
			variable_text = hour_set + "h " + minute_set + "m " + second_set + "s";
		} else if (minute_countdown != 1) {
			variable_text = minute_set + "m " + second_set + "s";
		} else {
			variable_text = second_set + "s";
		}
		return variable_text;
	}
}
