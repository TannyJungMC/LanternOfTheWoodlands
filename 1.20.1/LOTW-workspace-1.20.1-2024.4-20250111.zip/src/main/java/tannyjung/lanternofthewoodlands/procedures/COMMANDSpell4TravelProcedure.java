package tannyjung.lanternofthewoodlands.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContext;

public class COMMANDSpell4TravelProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		try {
			for (Entity entityiterator : EntityArgument.getEntities(arguments, "entity")) {
				for (int index0 = 0; index0 < 8; index0++) {
					if (!("Hit Block").isEmpty()) {
						if (CommandResultProcedure.execute(entityiterator, ReplaceIDProcedure.execute(entity, "execute positioned ~ ~1.5 ~ positioned ^ ^ ^0.75 " + "if block ~ ~ ~ #lanternofthewoodlands:passable_blocks"))) {
							{
								Entity _ent = entityiterator;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands()
											.performPrefixedCommand(
													new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4, _ent.getName().getString(),
															_ent.getDisplayName(), _ent.level().getServer(), _ent),
													("execute positioned ~ ~1.5 ~ positioned ^ ^ ^0.5 " + "if block ~ ~ ~ #lanternofthewoodlands:passable_blocks at @s run tp @s ^ ^ ^0.5"));
								}
							}
						} else {
							{
								Entity _ent = entityiterator;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands()
											.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
													_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent),
													("execute positioned ~ ~1.5 ~ positioned ^ ^ ^0.5 " + "run particle minecraft:campfire_cosy_smoke ~ ~ ~ 0 0 0 0.01 5 force"));
								}
							}
							{
								Entity _ent = entityiterator;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4, _ent.getName().getString(),
													_ent.getDisplayName(), _ent.level().getServer(), _ent),
											("execute positioned ~ ~1.5 ~ positioned ^ ^ ^0.5 " + "run playsound minecraft:item.trident.hit_ground ambient @a[distance=..100] ~ ~ ~ 0.5 0.75 0.025"));
								}
							}
							{
								Entity _ent = entityiterator;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
											4, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), ReplaceIDProcedure.execute(entity, "tag @s add <ID>-spell4_hit"));
								}
							}
							{
								Entity _ent = entityiterator;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
											4, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), ReplaceIDProcedure.execute(entity, "tag @s remove <ID>-spell4_shoot"));
								}
							}
						}
					}
					if (!("Hit Entity").isEmpty()) {
						if (CommandResultProcedure.execute(entityiterator, ReplaceIDProcedure.execute(entity, "execute positioned ~ ~1.5 ~ positioned ^ ^ ^0.75 " + "if entity @e[tag=!<USER>-ally,distance=..1.5]"))) {
							{
								Entity _ent = entityiterator;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
											4, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), ("execute positioned ~ ~1.5 ~ positioned ^ ^ ^0.75 " + "run particle minecraft:explosion ~ ~ ~ 0 0 0 0 1 force"));
								}
							}
							{
								Entity _ent = entityiterator;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4, _ent.getName().getString(),
													_ent.getDisplayName(), _ent.level().getServer(), _ent),
											("execute positioned ~ ~1.5 ~ positioned ^ ^ ^0.75 " + "run playsound minecraft:entity.player.attack.sweep ambient @a[distance=..100] ~ ~ ~ 1 1 0.025"));
								}
							}
							{
								Entity _ent = entityiterator;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4, _ent.getName().getString(),
													_ent.getDisplayName(), _ent.level().getServer(), _ent),
											ReplaceIDProcedure.execute(entity,
													"execute positioned ~ ~1.5 ~ positioned ^ ^ ^0.75 " + ("as @e[tag=!<USER>-ally,distance=..1.5] at @s run damage @s " + 10 + " minecraft:player_attack by @p[tag=<USER>]")));
								}
							}
						}
					}
				}
			}
		} catch (CommandSyntaxException e) {
			e.printStackTrace();
		}
	}
}
