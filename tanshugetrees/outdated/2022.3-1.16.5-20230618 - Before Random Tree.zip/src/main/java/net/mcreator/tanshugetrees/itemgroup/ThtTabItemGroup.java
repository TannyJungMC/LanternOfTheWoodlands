
package net.mcreator.tanshugetrees.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.tanshugetrees.block.C7blockBlock;
import net.mcreator.tanshugetrees.ThtModElements;

@ThtModElements.ModElement.Tag
public class ThtTabItemGroup extends ThtModElements.ModElement {
	public ThtTabItemGroup(ThtModElements instance) {
		super(instance, 333);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabtht_tab") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(C7blockBlock.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
