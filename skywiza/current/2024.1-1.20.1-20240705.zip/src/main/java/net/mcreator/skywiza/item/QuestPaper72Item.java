
package net.mcreator.skywiza.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class QuestPaper72Item extends Item {
	public QuestPaper72Item() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}
}
