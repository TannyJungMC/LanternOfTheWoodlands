package net.mcreator.tanshugetrees.procedures;

import net.minecraft.world.IWorld;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.ResourceLocation;

import net.mcreator.tanshugetrees.ThtModVariables;
import net.mcreator.tanshugetrees.ThtMod;

import java.util.Map;

public class D2rarityProcedure {

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				ThtMod.LOGGER.warn("Failed to load dependency world for procedure D2rarity!");
			return false;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				ThtMod.LOGGER.warn("Failed to load dependency x for procedure D2rarity!");
			return false;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				ThtMod.LOGGER.warn("Failed to load dependency y for procedure D2rarity!");
			return false;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				ThtMod.LOGGER.warn("Failed to load dependency z for procedure D2rarity!");
			return false;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		String biome = "";
		biome = ThtModVariables.MapVariables.get(world).d2_biome;
		return Math.random() <= 0.000001 * (ThtModVariables.MapVariables.get(world).percent_all / 100)
				* ThtModVariables.MapVariables.get(world).d2_rarity * (ThtModVariables.MapVariables.get(world).percent_d / 100)
				&& ((biome).equals("all") || !(biome).equals("all")
						&& (world.func_241828_r().getRegistry(Registry.BIOME_KEY).getKey(world.getBiome(new BlockPos(x, y, z))) != null
								&& world.func_241828_r().getRegistry(Registry.BIOME_KEY).getKey(world.getBiome(new BlockPos(x, y, z)))
										.equals(new ResourceLocation("the_void"))) == false
						&& world.func_241828_r().getRegistry(Registry.BIOME_KEY).getKey(world.getBiome(new BlockPos(x, y, z))) != null
						&& world.func_241828_r().getRegistry(Registry.BIOME_KEY).getKey(world.getBiome(new BlockPos(x, y, z)))
								.equals(new ResourceLocation(biome)));
	}
}
